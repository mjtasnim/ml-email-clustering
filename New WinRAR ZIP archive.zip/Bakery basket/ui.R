library(shiny)

shinyUI(fluidPage(
  
        sidebarLayout(
          sidebarPanel(
            selectInput("sup","select support", choices = c(0.1, 0.05, 0.01, 0.005)),
            selectInput("confi","select confidence", choices = c(0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1))
          ),
          mainPanel(
            verbatimTextOutput("mba")
          )
        )
  
))