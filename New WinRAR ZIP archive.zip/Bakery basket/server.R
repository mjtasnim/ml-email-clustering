library(shiny)
library(arules)

shinyServer(function(input,output){
  
  output$mba<-renderPrint({
    
    rules<-apriori(BreadBasket_DMS,parameter = list(support=as.numeric(input$sup), confidence=as.numeric(input$confi)))
    inspect(rules)
  }
    
    
    
  )
}
)